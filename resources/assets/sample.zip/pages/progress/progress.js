/**
 * @file demo page for swan
 * @author houyu
 */

/* globals Page */
Page({
});
