/**
 * @file demo slider componnent
 * @author lvlei
 */

/* globals Page */
Page({
    sliderChange(e) {
        console.log(e);
    }
});
