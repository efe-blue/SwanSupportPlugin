/**
 * @file test navigator componnent
 * @author lvlei
 */

/* eslint-disable fecs-camelcase */
/* globals Page */
Page({});
