/**
 * @demo page component for switch
 * @author lvlei
 */

/* globals Page */
/* eslint-disable new-cap */
Page({

});
