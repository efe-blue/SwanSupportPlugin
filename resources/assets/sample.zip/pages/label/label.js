/**
 * @file label的示例
 * @author houyu
 */

/* globals Page */
Page({
    data: {
        checkboxItems: [
            {name: 'CHN', value: '中国', checked: 'true'},
            {name: 'USA', value: '美国'}
        ],
        radioItems: [
            {name: 'CHN', value: '中国', checked: 'true'},
            {name: 'USA', value: '美国'}
        ]
    }
});
