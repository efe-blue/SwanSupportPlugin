/**
 * @file demo page for apiDemo
 * @author renzhonghua
 */
/* globals Page, swan */

Page({
    data: {
        title: 'openSetting'
    },

    openSetting() {
        swan.openSetting({});
    }
});
