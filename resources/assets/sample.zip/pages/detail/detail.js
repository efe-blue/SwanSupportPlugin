/**
 * @file demo page for swan
 * @author houyu
 */
/* globals Page */

Page({
	data: {
        title: '新建的页面'
    }
});
