/**
 * @file demo page for swan
 * @author houyu
 */
/* eslint-disable fecs-camelcase */
/* globals Page */
Page({});
