/**
 * @file test for view component
 * @author hujie08
 */

/* globals Page */
/* eslint-disable new-cap */
Page({

});
